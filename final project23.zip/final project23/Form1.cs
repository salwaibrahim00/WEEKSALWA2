﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project23
{
    public partial class Form1 : Form
    {
        decimal sum = 0;
        decimal[] nums = new decimal[4];
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(textBox1.Text, out nums[0]) &&
             decimal.TryParse(textBox2.Text, out nums[1]) &&
             decimal.TryParse(textBox3.Text, out nums[2]) &&
            decimal.TryParse(textBox4.Text, out nums[3]))



                for (int i = 0; i < nums.Length; i++)
                {

                    {
                        sum += nums[i];
                    }
                }

            decimal average = sum / nums.Length;
            textBox5.Text = sum.ToString();
            textBox6.Text = average.ToString("F2");
        }
    }
    }

